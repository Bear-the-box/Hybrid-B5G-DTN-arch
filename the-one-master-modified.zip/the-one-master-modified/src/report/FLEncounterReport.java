package report;

import core.ConnectionListener;
import core.DTNHost;
import core.Message;
import core.Settings;
import core.SimClock;
import core.Connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Enhanced Contact Report for Federated Learning Simulation
 * Logs: timestamp, host1, host2, contact duration, buffer availability, battery level
 */
public class FLEncounterReport extends Report implements ConnectionListener {

    private static class ConnectionInfo {
        DTNHost h1, h2;
        double startTime;

        public ConnectionInfo(DTNHost h1, DTNHost h2, double startTime) {
            this.h1 = h1;
            this.h2 = h2;
            this.startTime = startTime;
        }
    }

    private HashMap<String, ConnectionInfo> activeConnections = new HashMap<>();

    @Override
    protected void init() {
        super.init();
        this.activeConnections = new HashMap<>();
    }

    @Override
    public void hostsConnected(DTNHost host1, DTNHost host2) {
        if (isWarmup()) return;
        String key = getConnectionKey(host1, host2);
        activeConnections.put(key, new ConnectionInfo(host1, host2, SimClock.getTime()));
    }

    @Override
    public void hostsDisconnected(DTNHost host1, DTNHost host2) {
        if (isWarmup()) return;

        String key = getConnectionKey(host1, host2);
        ConnectionInfo ci = activeConnections.remove(key);
        if (ci == null) return; // connection started during warmup

        double duration = SimClock.getTime() - ci.startTime;
        DTNHost encountered = host2; // pick host2 as encountered

        double bufferUsage = encountered.getBufferOccupancy();
        double bufferSize = encountered.getBufferOccupancy();
        double bufferAvailableRatio = (bufferSize > 0) ? 1.0 - (bufferUsage / bufferSize) : 0.0;

        double batteryLevel = encountered.getConnections().size();

        if(containsDestination(host1, host2)){
            write(String.format(Locale.US, "%.2f,%s,%s,%.2f,%.2f,%.2f,%s,%s,%s",
                SimClock.getTime(),
                ci.h1.getAddress(),
                ci.h2.getAddress(),
                duration,
                bufferAvailableRatio,
                batteryLevel,contactedDestination(host1, host2),getHops(host1, host2),"true"));
        }else{
            write(String.format(Locale.US, "%.2f,%s,%s,%.2f,%.2f,%.2f,%s,%s,%s",
                SimClock.getTime(),
                ci.h1.getAddress(),
                ci.h2.getAddress(),
                duration,
                bufferAvailableRatio,
                batteryLevel,contactedDestination(host1, host2),"{}","false"));
        }
        
    }

    public boolean contactedDestination(DTNHost host1, DTNHost host2){
        boolean contacted = false;
        List<Message> messages = new ArrayList<>(host1.getMessageCollection());
        for(int index=0;index<messages.size() && !contacted;index++){
            if(host2.getHistoricalConnections().contains(messages.get(index).getTo())){
                contacted = true;
            }
        }
        return contacted;
    }

    public String getHops(DTNHost host1, DTNHost host2){
        List<Message> messages = new ArrayList<>(host1.getMessageCollection());
        boolean isDestination = false;
        String path = "{";
        for(int index=0;index<messages.size() && !isDestination;index++){
            if(messages.get(index).getTo().getAddress() == host2.getAddress()){
                for(int indey=0;indey<messages.get(index).getHops().size();indey++){
                    path = path + messages.get(index).getHops().get(indey).getAddress();
                    if(indey<messages.size()-1){
                        path = path + "->";
                    }
                }
                isDestination = true;
            }
        }
        path = path + "}";
        return path;
    }

    public boolean containsDestination(DTNHost host1, DTNHost host2){
        List<Message> messages = new ArrayList<>(host1.getMessageCollection());
        boolean isDestination = false;
        for(int index=0;index<messages.size() && !isDestination;index++){
            if(messages.get(index).getTo().getAddress() == host2.getAddress()){
                isDestination = true;
            }
        }
        return isDestination;
    }

    @Override
    public void done() {
        super.done();
    }

    public String getHeader() {
        return "timestamp,host1,host2,duration,buffer_availability,battery_level,contactedDestination,hoplist,delivered";
    }

    private String getConnectionKey(DTNHost h1, DTNHost h2) {
        int id1 = h1.getAddress();
        int id2 = h2.getAddress();
        return (id1 < id2) ? h1.getAddress() + "-" + h2.getAddress() : h2.getAddress() + "-" + h1.getAddress();
    }
}
