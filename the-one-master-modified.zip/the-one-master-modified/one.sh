#! /bin/sh
java -Xmx4G -cp target:lib/ECLA.jar:lib/DTNConsoleConnection.jar core.DTNSim $*
