javadoc -classpath ../target:../lib/ECLA.jar:../lib/DTNConsoleConnection.jar -sourcepath ../src/ -subpackages core:ui:gui:input:movement:report:routing:applications:interfaces:util
